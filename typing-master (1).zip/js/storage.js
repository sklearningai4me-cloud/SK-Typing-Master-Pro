// js/storage.js
class StorageManager {
    constructor() {
        this.dbName = 'TypeCrackDB';
        this.dbVersion = 1;
        this.db = null;
    }
    
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);
            
            request.onerror = () => {
                console.error('IndexedDB error:', request.error);
                reject(request.error);
            };
            
            request.onsuccess = () => {
                this.db = request.result;
                console.log('IndexedDB initialized');
                resolve();
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Create object stores
                if (!db.objectStoreNames.contains('profiles')) {
                    const profileStore = db.createObjectStore('profiles', { keyPath: 'id' });
                    profileStore.createIndex('name', 'name', { unique: true });
                    profileStore.createIndex('createdAt', 'createdAt');
                }
                
                if (!db.objectStoreNames.contains('sessions')) {
                    const sessionStore = db.createObjectStore('sessions', { keyPath: 'id' });
                    sessionStore.createIndex('profileId', 'profileId');
                    sessionStore.createIndex('date', 'date');
                    sessionStore.createIndex('wpm', 'wpm');
                }
                
                if (!db.objectStoreNames.contains('stats')) {
                    const statsStore = db.createObjectStore('stats', { keyPath: 'profileId' });
                }
                
                if (!db.objectStoreNames.contains('settings')) {
                    const settingsStore = db.createObjectStore('settings', { keyPath: 'key' });
                }
            };
        });
    }
    
    // Profile methods
    async createProfile(name) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['profiles'], 'readwrite');
            const store = transaction.objectStore('profiles');
            
            const profile = {
                id: Date.now().toString(),
                name: name,
                createdAt: new Date().toISOString(),
                lastActive: new Date().toISOString(),
                settings: {
                    theme: 'light',
                    sound: true,
                    fontSize: 'medium'
                }
            };
            
            const request = store.add(profile);
            
            request.onsuccess = () => {
                // Create initial stats
                this.createStats(profile.id);
                resolve(profile);
            };
            
            request.onerror = () => reject(request.error);
        });
    }
    
    async getProfiles() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['profiles'], 'readonly');
            const store = transaction.objectStore('profiles');
            const request = store.getAll();
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    
    async getProfile(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['profiles'], 'readonly');
            const store = transaction.objectStore('profiles');
            const request = store.get(id);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    
    async updateProfile(id, updates) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['profiles'], 'readwrite');
            const store = transaction.objectStore('profiles');
            
            store.get(id).onsuccess = (event) => {
                const profile = event.target.result;
                if (!profile) {
                    reject(new Error('Profile not found'));
                    return;
                }
                
                const updatedProfile = { ...profile, ...updates };
                const updateRequest = store.put(updatedProfile);
                
                updateRequest.onsuccess = () => resolve(updatedProfile);
                updateRequest.onerror = () => reject(updateRequest.error);
            };
        });
    }
    
    async deleteProfile(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['profiles', 'sessions', 'stats'], 'readwrite');
            const profileStore = transaction.objectStore('profiles');
            const sessionStore = transaction.objectStore('sessions');
            const statsStore = transaction.objectStore('stats');
            
            // Delete profile
            profileStore.delete(id);
            
            // Delete all sessions for this profile
            const sessionIndex = sessionStore.index('profileId');
            const sessionRequest = sessionIndex.openCursor(IDBKeyRange.only(id));
            
            sessionRequest.onsuccess = (event) => {
                const cursor = event.target.result;
                if (cursor) {
                    sessionStore.delete(cursor.primaryKey);
                    cursor.continue();
                }
            };
            
            // Delete stats
            statsStore.delete(id);
            
            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }
    
    // Stats methods
    async createStats(profileId) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['stats'], 'readwrite');
            const store = transaction.objectStore('stats');
            
            const stats = {
                profileId: profileId,
                averageWPM: 0,
                averageAccuracy: 0,
                bestWPM: 0,
                totalTime: 0,
                totalSessions: 0,
                totalWords: 0,
                totalErrors: 0,
                lastUpdated: new Date().toISOString()
            };
            
            const request = store.add(stats);
            
            request.onsuccess = () => resolve(stats);
            request.onerror = () => reject(request.error);
        });
    }
    
    async getStats(profileId) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['stats'], 'readonly');
            const store = transaction.objectStore('stats');
            const request = store.get(profileId);
            
            request.onsuccess = () => {
                resolve(request.result || {
                    profileId: profileId,
                    averageWPM: 0,
                    averageAccuracy: 0,
                    bestWPM: 0,
                    totalTime: 0,
                    totalSessions: 0,
                    totalWords: 0,
                    totalErrors: 0,
                    lastUpdated: new Date().toISOString()
                });
            };
            request.onerror = () => reject(request.error);
        });
    }
    
    async updateStats(profileId, sessionData) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['stats'], 'readwrite');
            const store = transaction.objectStore('stats');
            
            store.get(profileId).onsuccess = async (event) => {
                let stats = event.target.result;
                
                if (!stats) {
                    stats = await this.createStats(profileId);
                }
                
                // Update stats
                const oldTotalSessions = stats.totalSessions;
                const oldTotalTime = stats.totalTime;
                
                stats.totalSessions += 1;
                stats.totalTime += sessionData.duration;
                stats.totalWords += sessionData.wordCount || 0;
                stats.totalErrors += sessionData.errors || 0;
                
                // Recalculate averages
                stats.averageWPM = ((stats.averageWPM * oldTotalSessions) + sessionData.wpm) / stats.totalSessions;
                stats.averageAccuracy = ((stats.averageAccuracy * oldTotalSessions) + sessionData.accuracy) / stats.totalSessions;
                
                // Update best WPM if needed
                if (sessionData.wpm > stats.bestWPM) {
                    stats.bestWPM = sessionData.wpm;
                }
                
                stats.lastUpdated = new Date().toISOString();
                
                const updateRequest = store.put(stats);
                
                updateRequest.onsuccess = () => resolve(stats);
                updateRequest.onerror = () => reject(updateRequest.error);
            };
        });
    }
    
    // Session methods
    async saveSession(sessionData) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['sessions', 'stats'], 'readwrite');
            const sessionStore = transaction.objectStore('sessions');
            const statsStore = transaction.objectStore('stats');
            
            const session = {
                id: Date.now().toString(),
                ...sessionData,
                date: new Date().toISOString()
            };
            
            // Save session
            const sessionRequest = sessionStore.add(session);
            
            // Update stats
            statsStore.get(sessionData.profileId).onsuccess = (event) => {
                const stats = event.target.result;
                if (stats) {
                    const oldTotalSessions = stats.totalSessions;
                    const oldTotalTime = stats.totalTime;
                    
                    stats.totalSessions += 1;
                    stats.totalTime += sessionData.duration;
                    stats.totalWords += sessionData.wordCount || 0;
                    stats.totalErrors += sessionData.errors || 0;
                    
                    stats.averageWPM = ((stats.averageWPM * oldTotalSessions) + sessionData.wpm) / stats.totalSessions;
                    stats.averageAccuracy = ((stats.averageAccuracy * oldTotalSessions) + sessionData.accuracy) / stats.totalSessions;
                    
                    if (sessionData.wpm > stats.bestWPM) {
                        stats.bestWPM = sessionData.wpm;
                    }
                    
                    stats.lastUpdated = new Date().toISOString();
                    statsStore.put(stats);
                }
            };
            
            transaction.oncomplete = () => resolve(session);
            transaction.onerror = () => reject(transaction.error);
        });
    }
    
    async getSessions(profileId, limit = 50) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['sessions'], 'readonly');
            const store = transaction.objectStore('sessions');
            const index = store.index('profileId');
            const range = IDBKeyRange.only(profileId);
            
            const request = index.openCursor(range, 'prev');
            const sessions = [];
            
            request.onsuccess = (event) => {
                const cursor = event.target.result;
                if (cursor && sessions.length < limit) {
                    sessions.push(cursor.value);
                    cursor.continue();
                } else {
                    resolve(sessions);
                }
            };
            
            request.onerror = () => reject(request.error);
        });
    }
    
    async getSessionsByDate(profileId, startDate, endDate) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['sessions'], 'readonly');
            const store = transaction.objectStore('sessions');
            const index = store.index('date');
            const range = IDBKeyRange.bound(startDate, endDate);
            
            const request = index.openCursor(range);
            const sessions = [];
            
            request.onsuccess = (event) => {
                const cursor = event.target.result;
                if (cursor && cursor.value.profileId === profileId) {
                    sessions.push(cursor.value);
                    cursor.continue();
                } else if (cursor) {
                    cursor.continue();
                } else {
                    resolve(sessions);
                }
            };
            
            request.onerror = () => reject(request.error);
        });
    }
    
    // Settings methods
    async saveSetting(key, value) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['settings'], 'readwrite');
            const store = transaction.objectStore('settings');
            
            const setting = { key, value, updatedAt: new Date().toISOString() };
            const request = store.put(setting);
            
            request.onsuccess = () => resolve(setting);
            request.onerror = () => reject(request.error);
        });
    }
    
    async getSetting(key) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['settings'], 'readonly');
            const store = transaction.objectStore('settings');
            const request = store.get(key);
            
            request.onsuccess = () => resolve(request.result?.value);
            request.onerror = () => reject(request.error);
        });
    }
    
    async getAllSettings() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['settings'], 'readonly');
            const store = transaction.objectStore('settings');
            const request = store.getAll();
            
            request.onsuccess = () => {
                const settings = {};
                request.result.forEach(setting => {
                    settings[setting.key] = setting.value;
                });
                resolve(settings);
            };
            request.onerror = () => reject(request.error);
        });
    }
    
    // Export/Import methods
    async exportData(profileId) {
        const [profile, sessions, stats] = await Promise.all([
            this.getProfile(profileId),
            this.getSessions(profileId),
            this.getStats(profileId)
        ]);
        
        return {
            profile,
            sessions,
            stats,
            exportDate: new Date().toISOString(),
            version: '1.0'
        };
    }
    
    async importData(data) {
        // Validate data
        if (!data.profile || !data.sessions || !data.stats) {
            throw new Error('Invalid data format');
        }
        
        // Import profile (check if exists)
        const existingProfiles = await this.getProfiles();
        const existingProfile = existingProfiles.find(p => p.name === data.profile.name);
        
        if (existingProfile) {
            throw new Error('Profile with this name already exists');
        }
        
        // Create new profile
        const newProfile = await this.createProfile(data.profile.name);
        
        // Import stats
        await this.updateStats(newProfile.id, data.stats);
        
        // Import sessions
        for (const session of data.sessions) {
            await this.saveSession({
                ...session,
                profileId: newProfile.id,
                id: undefined // Let IndexedDB generate new ID
            });
        }
        
        return newProfile;
    }
    
    // Clear all data (for testing/reset)
    async clearAllData() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(
                ['profiles', 'sessions', 'stats', 'settings'],
                'readwrite'
            );
            
            transaction.objectStore('profiles').clear();
            transaction.objectStore('sessions').clear();
            transaction.objectStore('stats').clear();
            transaction.objectStore('settings').clear();
            
            transaction.oncomplete = () => {
                localStorage.clear();
                resolve();
            };
            
            transaction.onerror = () => reject(transaction.error);
        });
    }
}

// Create global storage instance
const storage = new StorageManager();