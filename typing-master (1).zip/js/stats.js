// js/stats.js
class StatisticsManager {
    constructor() {
        this.charts = {};
        this.currentProfile = null;
    }
    
    async init() {
        this.currentProfile = profiles.getCurrentProfile();
        if (!this.currentProfile) return;
        
        await this.loadStatistics();
        this.setupEventListeners();
    }
    
    async loadStatistics() {
        const stats = await storage.getStats(this.currentProfile.id);
        const sessions = await storage.getSessions(this.currentProfile.id, 100);
        
        this.updateOverview(stats);
        this.updateCharts(stats, sessions);
        this.updateDailyStats(sessions);
        this.updateInsights(stats, sessions);
    }
    
    updateOverview(stats) {
        // Update overview cards
        document.getElementById('overview-best-wpm')?.textContent = `${Math.round(stats.bestWPM)} WPM`;
        document.getElementById('overview-accuracy')?.textContent = `${Math.round(stats.averageAccuracy)}%`;
        
        // Format total time
        const hours = Math.floor(stats.totalTime / 3600);
        const minutes = Math.floor((stats.totalTime % 3600) / 60);
        const timeStr = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
        document.getElementById('overview-total-time')?.textContent = timeStr;
        
        document.getElementById('overview-sessions')?.textContent = stats.totalSessions;
        
        // Calculate trends (simplified)
        const wpmTrend = stats.bestWPM > 40 ? '+15%' : '+0%';
        const accuracyTrend = stats.averageAccuracy > 90 ? '+5%' : '+0%';
        
        document.getElementById('wpm-trend')?.textContent = `${wpmTrend} from last week`;
        document.getElementById('accuracy-trend')?.textContent = `${accuracyTrend} from last week`;
    }
    
    updateCharts(stats, sessions) {
        this.createWPMChart(sessions);
        this.createAccuracyChart(sessions);
        this.createDistributionCharts(sessions);
    }
    
    createWPMChart(sessions) {
        const canvas = document.getElementById('wpmChart');
        if (!canvas) return;
        
        // Group sessions by date (last 30 days)
        const last30Days = this.getLastNDays(30);
        const dailyWPM = {};
        
        sessions.forEach(session => {
            const date = new Date(session.date).toISOString().split('T')[0];
            if (!dailyWPM[date]) {
                dailyWPM[date] = [];
            }
            dailyWPM[date].push(session.wpm);
        });
        
        const dates = last30Days.map(date => {
            const d = new Date(date);
            return `${d.getDate()}/${d.getMonth() + 1}`;
        });
        
        const wpmData = last30Days.map(date => {
            const dailySessions = dailyWPM[date] || [];
            return dailySessions.length > 0 
                ? Math.round(dailySessions.reduce((a, b) => a + b, 0) / dailySessions.length)
                : 0;
        });
        
        // Create chart using simple canvas drawing
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        const padding = 40;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Draw grid
        ctx.strokeStyle = getComputedStyle(document.documentElement)
            .getPropertyValue('--border-color').trim();
        ctx.lineWidth = 1;
        
        // Vertical grid
        for (let i = 0; i <= 10; i++) {
            const x = padding + (i * (width - 2 * padding) / 10);
            ctx.beginPath();
            ctx.moveTo(x, padding);
            ctx.lineTo(x, height - padding);
            ctx.stroke();
        }
        
        // Horizontal grid
        const maxWPM = Math.max(...wpmData, 50);
        for (let i = 0; i <= 5; i++) {
            const y = height - padding - (i * (height - 2 * padding) / 5);
            ctx.beginPath();
            ctx.moveTo(padding, y);
            ctx.lineTo(width - padding, y);
            ctx.stroke();
        }
        
        // Draw line
        ctx.strokeStyle = getComputedStyle(document.documentElement)
            .getPropertyValue('--primary-color').trim();
        ctx.lineWidth = 3;
        ctx.beginPath();
        
        wpmData.forEach((wpm, index) => {
            if (wpm === 0) return;
            
            const x = padding + (index * (width - 2 * padding) / (wpmData.length - 1));
            const y = height - padding - (wpm * (height - 2 * padding) / maxWPM);
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        
        ctx.stroke();
        
        // Draw points
        ctx.fillStyle = getComputedStyle(document.documentElement)
            .getPropertyValue('--primary-color').trim();
        
        wpmData.forEach((wpm, index) => {
            if (wpm === 0) return;
            
            const x = padding + (index * (width - 2 * padding) / (wpmData.length - 1));
            const y = height - padding - (wpm * (height - 2 * padding) / maxWPM);
            
            ctx.beginPath();
            ctx.arc(x, y, 5, 0, Math.PI * 2);
            ctx.fill();
        });
    }
    
    createAccuracyChart(sessions) {
        const canvas = document.getElementById('accuracyChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        const padding = 40;
        
        ctx.clearRect(0, 0, width, height);
        
        // Get last 15 sessions accuracy
        const lastSessions = sessions.slice(0, 15).reverse();
        const accuracyData = lastSessions.map(s => s.accuracy);
        const labels = lastSessions.map((s, i) => `S${i + 1}`);
        
        // Draw bars
        const barWidth = (width - 2 * padding) / accuracyData.length - 10;
        const maxAccuracy = Math.max(...accuracyData, 100);
        
        accuracyData.forEach((accuracy, index) => {
            const x = padding + index * (barWidth + 10);
            const barHeight = (accuracy * (height - 2 * padding)) / maxAccuracy;
            const y = height - padding - barHeight;
            
            // Draw bar
            ctx.fillStyle = accuracy >= 95 ? '#4caf50' : 
                           accuracy >= 90 ? '#ff9800' : '#f44336';
            ctx.fillRect(x, y, barWidth, barHeight);
            
            // Draw value
            ctx.fillStyle = '#333';
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(`${Math.round(accuracy)}%`, x + barWidth / 2, y - 5);
            
            // Draw label
            ctx.fillText(labels[index], x + barWidth / 2, height - padding + 20);
        });
    }
    
    createDistributionCharts(sessions) {
        // Create speed distribution chart
        this.createDistributionChart(
            'speedDistributionChart',
            sessions.map(s => s.wpm),
            [0, 20, 40, 60, 80, 100],
            'WPM Distribution',
            'Speed (WPM)'
        );
        
        // Create time distribution chart
        this.createDistributionChart(
            'timeDistributionChart',
            sessions.map(s => Math.floor(s.duration / 60)), // Convert to minutes
            [0, 5, 10, 15, 20, 30],
            'Practice Time Distribution',
            'Duration (minutes)'
        );
    }
    
    createDistributionChart(canvasId, data, bins, title, xLabel) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        const padding = 40;
        
        ctx.clearRect(0, 0, width, height);
        
        // Create histogram
        const histogram = {};
        bins.forEach((bin, i) => {
            if (i < bins.length - 1) {
                histogram[`${bin}-${bins[i + 1]}`] = 0;
            }
        });
        
        data.forEach(value => {
            for (let i = 0; i < bins.length - 1; i++) {
                if (value >= bins[i] && value < bins[i + 1]) {
                    const key = `${bins[i]}-${bins[i + 1]}`;
                    histogram[key]++;
                    break;
                }
            }
        });
        
        const values = Object.values(histogram);
        const maxValue = Math.max(...values);
        
        // Draw bars
        const barWidth = (width - 2 * padding) / values.length - 5;
        
        values.forEach((count, index) => {
            const x = padding + index * (barWidth + 5);
            const barHeight = (count * (height - 2 * padding)) / maxValue;
            const y = height - padding - barHeight;
            
            // Draw bar
            ctx.fillStyle = getComputedStyle(document.documentElement)
                .getPropertyValue('--primary-color').trim();
            ctx.fillRect(x, y, barWidth, barHeight);
            
            // Draw count
            ctx.fillStyle = '#333';
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            if (count > 0) {
                ctx.fillText(count.toString(), x + barWidth / 2, y - 5);
            }
            
            // Draw bin label
            const labels = Object.keys(histogram);
            ctx.fillText(labels[index].split('-')[0], x + barWidth / 2, height - padding + 15);
        });
        
        // Draw title
        ctx.fillStyle = '#333';
        ctx.font = '14px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(title, width / 2, 20);
        
        // Draw x-axis label
        ctx.fillText(xLabel, width / 2, height - 10);
    }
    
    updateDailyStats(sessions) {
        const tbody = document.getElementById('daily-stats-body');
        if (!tbody) return;
        
        // Group sessions by date
        const sessionsByDate = {};
        sessions.forEach(session => {
            const date = new Date(session.date).toISOString().split('T')[0];
            if (!sessionsByDate[date]) {
                sessionsByDate[date] = [];
            }
            sessionsByDate[date].push(session);
        });
        
        // Create table rows
        tbody.innerHTML = '';
        
        Object.entries(sessionsByDate).forEach(([date, dailySessions]) => {
            const totalDuration = dailySessions.reduce((sum, s) => sum + s.duration, 0);
            const bestWPM = Math.max(...dailySessions.map(s => s.wpm));
            const avgAccuracy = dailySessions.reduce((sum, s) => sum + s.accuracy, 0) / dailySessions.length;
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${this.formatDate(date)}</td>
                <td>${dailySessions.length}</td>
                <td>${Math.floor(totalDuration / 60)}m</td>
                <td>${Math.round(bestWPM)}</td>
                <td>${Math.round(avgAccuracy)}%</td>
                <td>
                    <button class="btn-small" onclick="viewSessionDetails('${date}')">
                        View
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
    
    updateInsights(stats, sessions) {
        const insightsList = document.getElementById('insights-list');
        if (!insightsList) return;
        
        insightsList.innerHTML = '';
        
        // Generate insights based on data
        const insights = [];
        
        if (sessions.length === 0) {
            insights.push({
                icon: '👋',
                text: 'Welcome! Start your first practice session to see insights.',
                date: 'Today'
            });
        } else {
            // Recent improvement
            const recentSessions = sessions.slice(0, 5);
            const oldSessions = sessions.slice(5, 10);
            
            if (recentSessions.length >= 3 && oldSessions.length >= 3) {
                const recentAvg = recentSessions.reduce((a, b) => a + b.wpm, 0) / recentSessions.length;
                const oldAvg = oldSessions.reduce((a, b) => a + b.wpm, 0) / oldSessions.length;
                
                if (recentAvg > oldAvg * 1.1) {
                    insights.push({
                        icon: '🚀',
                        text: `Your speed improved by ${Math.round((recentAvg - oldAvg) / oldAvg * 100)}% recently!`,
                        date: 'Today'
                    });
                }
            }
            
            // Consistency check
            const lastWeekSessions = sessions.filter(s => {
                const sessionDate = new Date(s.date);
                const weekAgo = new Date();
                weekAgo.setDate(weekAgo.getDate() - 7);
                return sessionDate > weekAgo;
            });
            
            if (lastWeekSessions.length >= 5) {
                insights.push({
                    icon: '🔥',
                    text: `Great consistency! ${lastWeekSessions.length} sessions in the last week.`,
                    date: 'This week'
                });
            }
            
            // Accuracy insight
            if (stats.averageAccuracy >= 95) {
                insights.push({
                    icon: '🎯',
                    text: 'Excellent accuracy! You maintain 95%+ accuracy consistently.',
                    date: 'Today'
                });
            } else if (stats.averageAccuracy < 90) {
                insights.push({
                    icon: '💡',
                    text: 'Focus on accuracy. Try slowing down for better precision.',
                    date: 'Today'
                });
            }
            
            // Practice time insight
            const totalHours = stats.totalTime / 3600;
            if (totalHours >= 10) {
                insights.push({
                    icon: '⭐',
                    text: `Amazing dedication! You've practiced for ${Math.round(totalHours)} hours total.`,
                    date: 'Overall'
                });
            }
        }
        
        // Add default insight if none
        if (insights.length === 0) {
            insights.push({
                icon: '💪',
                text: 'Keep practicing regularly to see detailed insights about your progress.',
                date: 'Today'
            });
        }
        
        // Render insights
        insights.forEach(insight => {
            const insightEl = document.createElement('div');
            insightEl.className = 'insight-item';
            insightEl.innerHTML = `
                <span class="insight-icon">${insight.icon}</span>
                <div>
                    <p>${insight.text}</p>
                    <span class="insight-date">${insight.date}</span>
                </div>
            `;
            insightsList.appendChild(insightEl);
        });
    }
    
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }
    
    getLastNDays(n) {
        const dates = [];
        for (let i = n - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            dates.push(date.toISOString().split('T')[0]);
        }
        return dates;
    }
    
    setupEventListeners() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                this.switchTab(tab);
            });
        });
    }
    
    switchTab(tabName) {
        // Update active tab button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
        
        // Show selected tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.id === `tab-${tabName}`);
        });
        
        // Load data for tab if needed
        if (tabName === 'comparison') {
            this.loadComparisonData();
        }
    }
    
    async loadComparisonData() {
        // Load comparison data
        const sessions = await storage.getSessions(this.currentProfile.id, 100);
        
        // Implement comparison logic here
        console.log('Loading comparison data...');
    }
    
    async exportStats() {
        const data = await storage.exportData(this.currentProfile.id);
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `typecrack-stats-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        app.showToast('Statistics exported successfully', 'success');
    }
    
    async resetStats() {
        if (!confirm('Are you sure? This will reset all your statistics and cannot be undone.')) {
            return;
        }
        
        // Clear all sessions for current profile
        const sessions = await storage.getSessions(this.currentProfile.id);
        const transaction = storage.db.transaction(['sessions', 'stats'], 'readwrite');
        const sessionStore = transaction.objectStore('sessions');
        const statsStore = transaction.objectStore('stats');
        
        // Delete all sessions
        sessions.forEach(session => {
            sessionStore.delete(session.id);
        });
        
        // Reset stats
        const stats = await storage.getStats(this.currentProfile.id);
        stats.averageWPM = 0;
        stats.averageAccuracy = 0;
        stats.bestWPM = 0;
        stats.totalTime = 0;
        stats.totalSessions = 0;
        stats.totalWords = 0;
        stats.totalErrors = 0;
        stats.lastUpdated = new Date().toISOString();
        
        statsStore.put(stats);
        
        transaction.oncomplete = () => {
            app.showToast('Statistics reset successfully', 'success');
            this.loadStatistics();
        };
    }
    
    printStats() {
        window.print();
    }
}

// Create global stats instance
const statsManager = new StatisticsManager();