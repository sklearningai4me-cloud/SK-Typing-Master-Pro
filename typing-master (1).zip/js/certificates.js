// js/certificates.js
class CertificateManager {
    constructor() {
        this.certificates = [];
        this.currentProfile = null;
    }
    
    async init() {
        this.currentProfile = profiles.getCurrentProfile();
        if (!this.currentProfile) return;
        
        await this.loadCertificates();
    }
    
    async loadCertificates() {
        // Load certificates from storage
        const storedCerts = localStorage.getItem(`certificates_${this.currentProfile.id}`);
        if (storedCerts) {
            this.certificates = JSON.parse(storedCerts);
        }
        
        this.renderCertificates();
    }
    
    async generateCertificate(type, data = {}) {
        if (!this.currentProfile) return;
        
        const certificate = {
            id: Date.now().toString(),
            profileId: this.currentProfile.id,
            type: type,
            date: new Date().toISOString(),
            data: data,
            issued: true
        };
        
        // Add certificate data based on type
        switch (type) {
            case 'wpm':
                certificate.title = 'Speed Master Certificate';
                certificate.description = `Achieved ${data.wpm} WPM typing speed`;
                certificate.badge = '🚀';
                break;
                
            case 'accuracy':
                certificate.title = 'Accuracy Expert Certificate';
                certificate.description = `Achieved ${data.accuracy}% typing accuracy`;
                certificate.badge = '🎯';
                break;
                
            case 'consistency':
                certificate.title = 'Consistency Champion Certificate';
                certificate.description = `Practiced for ${data.days} consecutive days`;
                certificate.badge = '🔥';
                break;
                
            case 'ssc':
                certificate.title = 'SSC Ready Certificate';
                certificate.description = 'Passed SSC typing test simulation';
                certificate.badge = '📜';
                break;
                
            default:
                certificate.title = 'Achievement Certificate';
                certificate.description = 'Great work on improving your typing skills!';
                certificate.badge = '⭐';
        }
        
        this.certificates.unshift(certificate);
        await this.saveCertificates();
        
        this.renderCertificates();
        this.showCertificateModal(certificate);
        
        app.showToast('Certificate generated successfully!', 'success');
        return certificate;
    }
    
    async checkForAchievements(sessionData) {
        if (!this.currentProfile) return;
        
        const stats = await storage.getStats(this.currentProfile.id);
        const sessions = await storage.getSessions(this.currentProfile.id, 100);
        
        const achievements = [];
        
        // Check for speed achievements
        if (sessionData.wpm >= 20 && !this.hasCertificate('wpm_20')) {
            achievements.push({
                type: 'wpm',
                data: { wpm: 20 },
                level: 'beginner'
            });
        }
        
        if (sessionData.wpm >= 40 && !this.hasCertificate('wpm_40')) {
            achievements.push({
                type: 'wpm',
                data: { wpm: 40 },
                level: 'intermediate'
            });
        }
        
        if (sessionData.wpm >= 60 && !this.hasCertificate('wpm_60')) {
            achievements.push({
                type: 'wpm',
                data: { wpm: 60 },
                level: 'advanced'
            });
        }
        
        // Check for accuracy achievements
        if (sessionData.accuracy >= 95 && !this.hasCertificate('accuracy_95')) {
            achievements.push({
                type: 'accuracy',
                data: { accuracy: 95 },
                level: 'expert'
            });
        }
        
        // Check for SSC simulation pass
        if (sessionData.wpm >= 35 && sessionData.accuracy >= 95 && 
            sessionData.title?.includes('SSC') && !this.hasCertificate('ssc')) {
            achievements.push({
                type: 'ssc',
                data: { wpm: sessionData.wpm, accuracy: sessionData.accuracy },
                level: 'professional'
            });
        }
        
        // Generate certificates for achievements
        for (const achievement of achievements) {
            await this.generateCertificate(achievement.type, achievement.data);
        }
        
        return achievements;
    }
    
    hasCertificate(type) {
        return this.certificates.some(cert => 
            cert.type === type || cert.data?.wpm === type.split('_')[1]
        );
    }
    
    async saveCertificates() {
        if (!this.currentProfile) return;
        
        localStorage.setItem(
            `certificates_${this.currentProfile.id}`,
            JSON.stringify(this.certificates)
        );
    }
    
    renderCertificates() {
        const container = document.getElementById('certificates-grid');
        const emptyState = document.getElementById('no-certificates');
        
        if (!container) return;
        
        if (this.certificates.length === 0) {
            if (emptyState) emptyState.style.display = 'block';
            container.innerHTML = '';
            return;
        }
        
        if (emptyState) emptyState.style.display = 'none';
        
        container.innerHTML = this.certificates.map(cert => `
            <div class="certificate-card" data-certificate-id="${cert.id}">
                <div class="certificate-header">
                    <span class="certificate-badge">${cert.badge}</span>
                    <div>
                        <h4>${cert.title}</h4>
                        <p class="certificate-date">${this.formatDate(cert.date)}</p>
                    </div>
                </div>
                <div class="certificate-body">
                    <p>${cert.description}</p>
                </div>
                <div class="certificate-actions">
                    <button class="btn-small" onclick="certManager.viewCertificate('${cert.id}')">
                        <span>👁️</span> View
                    </button>
                    <button class="btn-small" onclick="certManager.downloadCertificate('${cert.id}')">
                        <span>📥</span> Download
                    </button>
                    <button class="btn-small" onclick="certManager.shareCertificate('${cert.id}')">
                        <span>📤</span> Share
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
        });
    }
    
    viewCertificate(certificateId) {
        const certificate = this.certificates.find(c => c.id === certificateId);
        if (!certificate) return;
        
        this.showCertificateModal(certificate);
    }
    
    showCertificateModal(certificate) {
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content certificate-modal">
                <div class="modal-header">
                    <h2>🎉 Certificate of Achievement</h2>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="certificate-preview">
                        <div class="certificate-border">
                            <div class="certificate-title">
                                <h1>${certificate.title}</h1>
                                <p>This certificate is proudly presented to</p>
                            </div>
                            
                            <div class="certificate-recipient">
                                <h2>${this.currentProfile?.name || 'User'}</h2>
                                <p>For outstanding achievement in typing proficiency</p>
                            </div>
                            
                            <div class="certificate-details">
                                <p>${certificate.description}</p>
                                <p>Achieved on: ${this.formatDate(certificate.date)}</p>
                            </div>
                            
                            <div class="certificate-footer">
                                <div class="signature">
                                    <div class="signature-line"></div>
                                    <p>TypeCrack Pro</p>
                                </div>
                                <div class="seal">
                                    <span class="seal-icon">🏅</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-outline" onclick="this.closest('.modal').remove()">
                        Close
                    </button>
                    <button class="btn-primary" onclick="certManager.downloadCertificate('${certificate.id}')">
                        <span>📥</span> Download PDF
                    </button>
                    <button class="btn-secondary" onclick="certManager.printCertificate('${certificate.id}')">
                        <span>🖨️</span> Print
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }
    
    downloadCertificate(certificateId) {
        const certificate = this.certificates.find(c => c.id === certificateId);
        if (!certificate) return;
        
        // Create PDF-like HTML content
        const content = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>${certificate.title}</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
                    .certificate { border: 3px solid #000; padding: 40px; text-align: center; }
                    .title { font-size: 32px; color: #2c3e50; margin-bottom: 10px; }
                    .recipient { font-size: 28px; color: #e74c3c; margin: 30px 0; }
                    .details { font-size: 18px; margin: 20px 0; }
                    .footer { margin-top: 40px; display: flex; justify-content: space-between; }
                    .signature { text-align: center; }
                    .seal { font-size: 48px; }
                </style>
            </head>
            <body>
                <div class="certificate">
                    <div class="title">${certificate.title}</div>
                    <p>This certificate is proudly presented to</p>
                    <div class="recipient">${this.currentProfile?.name || 'User'}</div>
                    <div class="details">
                        <p>${certificate.description}</p>
                        <p>Achieved on: ${this.formatDate(certificate.date)}</p>
                    </div>
                    <div class="footer">
                        <div class="signature">
                            <div style="border-top: 2px solid #000; width: 200px; margin: 0 auto;"></div>
                            <p>TypeCrack Pro</p>
                        </div>
                        <div class="seal">🏅</div>
                    </div>
                </div>
            </body>
            </html>
        `;
        
        // Create download link
        const blob = new Blob([content], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `certificate-${certificate.id}.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        app.showToast('Certificate downloaded', 'success');
    }
    
    printCertificate(certificateId) {
        const certificate = this.certificates.find(c => c.id === certificateId);
        if (!certificate) return;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
            <head>
                <title>Print Certificate</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 40px; }
                    .certificate { border: 3px solid #000; padding: 60px; text-align: center; }
                    h1 { color: #2c3e50; }
                    h2 { color: #e74c3c; }
                </style>
            </head>
            <body>
                <div class="certificate">
                    <h1>${certificate.title}</h1>
                    <p>This certificate is proudly presented to</p>
                    <h2>${this.currentProfile?.name || 'User'}</h2>
                    <p>${certificate.description}</p>
                    <p>Achieved on: ${this.formatDate(certificate.date)}</p>
                    <br><br>
                    <p>TypeCrack Pro - Offline Typing Master</p>
                </div>
                <script>
                    window.onload = () => window.print();
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    }
    
    shareCertificate(certificateId) {
        const certificate = this.certificates.find(c => c.id === certificateId);
        if (!certificate) return;
        
        if (navigator.share) {
            navigator.share({
                title: certificate.title,
                text: `I earned "${certificate.title}" on TypeCrack Pro! ${certificate.description}`,
                url: window.location.href
            }).then(() => {
                app.showToast('Certificate shared!', 'success');
            }).catch(console.error);
        } else {
            // Fallback: copy to clipboard
            const text = `🏆 ${certificate.title}\n\n${certificate.description}\n\nAchieved on TypeCrack Pro`;
            
            navigator.clipboard.writeText(text).then(() => {
                app.showToast('Certificate text copied to clipboard', 'success');
            });
        }
    }
    
    async generateDailyCertificate() {
        if (!this.currentProfile) return;
        
        const stats = await storage.getStats(this.currentProfile.id);
        const today = new Date().toISOString().split('T')[0];
        
        // Check if certificate already issued today
        const todayCert = this.certificates.find(cert => 
            cert.date.startsWith(today) && cert.type === 'daily'
        );
        
        if (todayCert) return null;
        
        // Issue daily practice certificate if criteria met
        const sessions = await storage.getSessions(this.currentProfile.id);
        const todaySessions = sessions.filter(s => s.date.startsWith(today));
        
        if (todaySessions.length > 0) {
            const totalTime = todaySessions.reduce((sum, s) => sum + s.duration, 0);
            
            if (totalTime >= 1800) { // 30 minutes
                return await this.generateCertificate('consistency', {
                    days: 1,
                    minutes: Math.floor(totalTime / 60)
                });
            }
        }
        
        return null;
    }
}

// Create global certificate manager
const certManager = new CertificateManager();