// js/themes.js
class ThemeManager {
    constructor() {
        this.currentTheme = 'light';
        this.themes = {
            'light': 'Light',
            'dark': 'Dark',
            'sepia': 'Sepia',
            'night-blue': 'Night Blue',
            'green-matrix': 'Green Matrix',
            'paper-white': 'Paper White',
            'ssc-exam': 'SSC Exam Mode'
        };
    }
    
    init() {
        this.loadTheme();
        this.setupEventListeners();
    }
    
    loadTheme() {
        // Try to load from localStorage
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.applyTheme(savedTheme);
        
        // Update theme picker if exists
        this.updateThemePicker();
    }
    
    applyTheme(themeName) {
        if (!this.themes[themeName]) {
            themeName = 'light';
        }
        
        // Remove all theme classes
        document.body.classList.remove(
            ...Object.keys(this.themes).map(theme => `theme-${theme}`)
        );
        
        // Add selected theme class
        document.body.classList.add(`theme-${themeName}`);
        
        // Update current theme
        this.currentTheme = themeName;
        
        // Save to localStorage
        localStorage.setItem('theme', themeName);
        
        // Update theme picker UI
        this.updateThemePicker();
        
        // Update CSS variables for charts
        this.updateChartColors();
    }
    
    updateThemePicker() {
        // Update theme options
        document.querySelectorAll('.theme-option').forEach(option => {
            const theme = option.dataset.theme;
            option.classList.toggle('active', theme === this.currentTheme);
        });
        
        // Update theme select dropdown
        const themeSelect = document.getElementById('theme-select');
        if (themeSelect) {
            themeSelect.value = this.currentTheme;
        }
    }
    
    updateChartColors() {
        // Get current theme colors
        const style = getComputedStyle(document.body);
        const primaryColor = style.getPropertyValue('--primary-color').trim();
        const secondaryColor = style.getPropertyValue('--secondary-color').trim();
        const accentColor = style.getPropertyValue('--accent-color').trim();
        
        // Update chart colors if charts exist
        if (window.statsManager && window.statsManager.charts) {
            Object.values(window.statsManager.charts).forEach(chart => {
                if (chart.updateColors) {
                    chart.updateColors(primaryColor, secondaryColor, accentColor);
                }
            });
        }
    }
    
    setupEventListeners() {
        // Theme option clicks
        document.addEventListener('click', (e) => {
            const themeOption = e.target.closest('.theme-option');
            if (themeOption) {
                const theme = themeOption.dataset.theme;
                this.applyTheme(theme);
                app.showToast(`Theme changed to ${this.themes[theme]}`, 'success');
            }
        });
        
        // Theme select change
        const themeSelect = document.getElementById('theme-select');
        if (themeSelect) {
            themeSelect.addEventListener('change', (e) => {
                this.applyTheme(e.target.value);
            });
        }
        
        // Keyboard shortcut for theme toggle (Alt+T)
        document.addEventListener('keydown', (e) => {
            if (e.altKey && e.key === 't') {
                e.preventDefault();
                this.toggleDarkMode();
            }
        });
    }
    
    toggleDarkMode() {
        const isDark = document.body.classList.contains('theme-dark');
        this.applyTheme(isDark ? 'light' : 'dark');
        
        app.showToast(
            `Switched to ${isDark ? 'Light' : 'Dark'} mode`,
            'success'
        );
    }
    
    getCurrentTheme() {
        return this.currentTheme;
    }
    
    getThemeColors() {
        const style = getComputedStyle(document.body);
        return {
            primary: style.getPropertyValue('--primary-color').trim(),
            secondary: style.getPropertyValue('--secondary-color').trim(),
            accent: style.getPropertyValue('--accent-color').trim(),
            background: style.getPropertyValue('--background-color').trim(),
            surface: style.getPropertyValue('--surface-color').trim(),
            textPrimary: style.getPropertyValue('--text-primary').trim(),
            textSecondary: style.getPropertyValue('--text-secondary').trim()
        };
    }
    
    applyAccessibilitySettings(settings) {
        // Apply font size
        document.body.classList.remove(
            'font-size-small',
            'font-size-medium',
            'font-size-large',
            'font-size-xlarge'
        );
        
        if (settings.fontSize) {
            document.body.classList.add(`font-size-${settings.fontSize}`);
        }
        
        // Apply high contrast
        document.body.classList.remove('theme-high-contrast');
        if (settings.highContrast) {
            document.body.classList.add('theme-high-contrast');
        }
        
        // Apply reduced animations
        if (settings.reduceAnimations) {
            document.body.classList.add('reduce-animations');
        } else {
            document.body.classList.remove('reduce-animations');
        }
        
        // Save settings
        localStorage.setItem('accessibility', JSON.stringify(settings));
    }
    
    getAccessibilitySettings() {
        const saved = localStorage.getItem('accessibility');
        return saved ? JSON.parse(saved) : {
            fontSize: 'medium',
            highContrast: false,
            reduceAnimations: false
        };
    }
}

// Create global theme manager
const themeManager = new ThemeManager();