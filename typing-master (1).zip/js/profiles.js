// js/profiles.js
class ProfileManager {
    constructor() {
        this.currentProfile = null;
        this.profiles = [];
    }
    
    async init() {
        await this.loadProfiles();
        
        // Try to get last used profile from localStorage
        const lastProfileId = localStorage.getItem('lastProfileId');
        if (lastProfileId) {
            this.currentProfile = await storage.getProfile(lastProfileId);
        }
        
        // If no profile exists, create a default one
        if (!this.currentProfile && this.profiles.length === 0) {
            this.currentProfile = await this.createProfile('Guest');
        } else if (!this.currentProfile && this.profiles.length > 0) {
            this.currentProfile = this.profiles[0];
        }
        
        // Save current profile ID
        if (this.currentProfile) {
            localStorage.setItem('lastProfileId', this.currentProfile.id);
        }
        
        return this.currentProfile;
    }
    
    async loadProfiles() {
        this.profiles = await storage.getProfiles();
        return this.profiles;
    }
    
    async createProfile(name) {
        const profile = await storage.createProfile(name);
        this.profiles.push(profile);
        
        // If this is the first profile, set it as current
        if (this.profiles.length === 1) {
            await this.switchProfile(profile.id);
        }
        
        app.showToast(`Profile "${name}" created successfully`, 'success');
        return profile;
    }
    
    async switchProfile(profileId) {
        const profile = await storage.getProfile(profileId);
        if (!profile) {
            app.showToast('Profile not found', 'error');
            return;
        }
        
        this.currentProfile = profile;
        localStorage.setItem('lastProfileId', profileId);
        
        // Update profile last active time
        await storage.updateProfile(profileId, {
            lastActive: new Date().toISOString()
        });
        
        // Update UI
        app.updateProfileUI();
        app.loadQuickStats();
        
        app.showToast(`Switched to ${profile.name}`, 'success');
        return profile;
    }
    
    async updateProfile(profileId, updates) {
        const updatedProfile = await storage.updateProfile(profileId, updates);
        
        // Update in local array
        const index = this.profiles.findIndex(p => p.id === profileId);
        if (index !== -1) {
            this.profiles[index] = updatedProfile;
        }
        
        // If current profile was updated, update reference
        if (this.currentProfile?.id === profileId) {
            this.currentProfile = updatedProfile;
        }
        
        return updatedProfile;
    }
    
    async deleteProfile(profileId) {
        // Don't allow deleting if it's the only profile
        if (this.profiles.length <= 1) {
            app.showToast('Cannot delete the only profile', 'error');
            return false;
        }
        
        if (!confirm('Are you sure? All data for this profile will be deleted permanently.')) {
            return false;
        }
        
        await storage.deleteProfile(profileId);
        
        // Remove from local array
        this.profiles = this.profiles.filter(p => p.id !== profileId);
        
        // If current profile was deleted, switch to another
        if (this.currentProfile?.id === profileId) {
            await this.switchProfile(this.profiles[0].id);
        }
        
        app.showToast('Profile deleted successfully', 'success');
        return true;
    }
    
    getCurrentProfile() {
        return this.currentProfile;
    }
    
    getAllProfiles() {
        return this.profiles;
    }
    
    async exportProfileData(profileId) {
        const data = await storage.exportData(profileId);
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `typecrack-profile-${data.profile.name}-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        app.showToast('Profile data exported successfully', 'success');
    }
    
    async importProfileData(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = async (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    const profile = await storage.importData(data);
                    
                    // Reload profiles
                    await this.loadProfiles();
                    
                    app.showToast('Profile data imported successfully', 'success');
                    resolve(profile);
                } catch (error) {
                    app.showToast(`Import failed: ${error.message}`, 'error');
                    reject(error);
                }
            };
            
            reader.onerror = () => {
                app.showToast('Error reading file', 'error');
                reject(new Error('File read error'));
            };
            
            reader.readAsText(file);
        });
    }
}

// Create global profiles instance
const profiles = new ProfileManager();