{
  "service-worker.js": `// Service Worker for TypeCrack Pro
const CACHE_NAME = 'typecrack-pro-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/css/base.css',
  '/css/layout.css',
  '/css/themes.css',
  '/css/animations.css',
  '/js/app.js',
  '/js/router.js',
  '/js/storage.js',
  '/js/typing-engine.js',
  '/js/profiles.js',
  '/js/stats.js',
  '/js/certificates.js',
  '/js/themes.js',
  '/pages/home.html',
  '/pages/lessons.html',
  '/pages/practice.html',
  '/pages/stats.html',
  '/pages/profile.html',
  '/pages/settings.html',
  '/data/lessons-basic.json',
  '/data/lessons-numbers.json',
  '/data/lessons-special.json',
  '/data/lessons-small.json',
  '/data/lessons-medium.json',
  '/data/lessons-large.json',
  '/data/lessons-ssc.json',
  '/assets/icons/icon-192.png',
  '/assets/icons/icon-512.png'
];

// Install event
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(ASSETS_TO_CACHE))
      .then(() => self.skipWaiting())
  );
});

// Activate event
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event
self.addEventListener('fetch', event => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          return response;
        }

        return fetch(event.request)
          .then(response => {
            // Don't cache if not a valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clone the response
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });

            return response;
          });
      })
      .catch(() => {
        // If both cache and network fail, show offline page
        if (event.request.url.includes('.html')) {
          return caches.match('/index.html');
        }
      })
  );
});

// Handle messages from the client
self.addEventListener('message', event => {
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
});`
}