// js/app.js
class TypeCrackPro {
    constructor() {
        this.currentPage = 'home';
        this.currentProfile = null;
        this.currentLesson = null;
        this.typingSession = null;
        this.deferredPrompt = null;
        
        this.init();
    }
    
    async init() {
        // Initialize storage
        await storage.init();
        
        // Load current profile
        this.currentProfile = await profiles.getCurrentProfile();
        
        // Initialize router
        this.router = new Router();
        
        // Setup install prompt
        this.setupInstallPrompt();
        
        // Update UI with profile data
        this.updateProfileUI();
        
        // Load stats
        this.loadQuickStats();
    }
    
    setupInstallPrompt() {
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            this.deferredPrompt = e;
            const installBtn = document.getElementById('install-btn');
            if (installBtn) {
                installBtn.style.display = 'flex';
                installBtn.addEventListener('click', () => this.installApp());
            }
        });
    }
    
    async installApp() {
        if (!this.deferredPrompt) return;
        
        this.deferredPrompt.prompt();
        const { outcome } = await this.deferredPrompt.userChoice;
        
        if (outcome === 'accepted') {
            const installBtn = document.getElementById('install-btn');
            if (installBtn) installBtn.style.display = 'none';
        }
        
        this.deferredPrompt = null;
    }
    
    updateProfileUI() {
        const profileNameEl = document.getElementById('current-profile-name');
        if (profileNameEl && this.currentProfile) {
            profileNameEl.textContent = this.currentProfile.name;
        }
    }
    
    async loadQuickStats() {
        if (!this.currentProfile) return;
        
        const stats = await storage.getStats(this.currentProfile.id);
        
        // Update WPM
        const wpmEl = document.getElementById('current-wpm');
        if (wpmEl && stats.averageWPM > 0) {
            wpmEl.textContent = `${Math.round(stats.averageWPM)} WPM`;
        }
        
        // Update Accuracy
        const accuracyEl = document.getElementById('current-accuracy');
        if (accuracyEl && stats.averageAccuracy > 0) {
            accuracyEl.textContent = `${Math.round(stats.averageAccuracy)}%`;
        }
        
        // Update Total Time
        const timeEl = document.getElementById('total-time');
        if (timeEl && stats.totalTime > 0) {
            const hours = Math.floor(stats.totalTime / 3600);
            const minutes = Math.floor((stats.totalTime % 3600) / 60);
            
            if (hours > 0) {
                timeEl.textContent = `${hours}h ${minutes}m`;
            } else {
                timeEl.textContent = `${minutes} min`;
            }
        }
    }
    
    showToast(message, type = 'info') {
        const toastContainer = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        toastContainer.appendChild(toast);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
}

// Router Class
class Router {
    constructor() {
        this.currentPage = 'home';
        this.init();
    }
    
    init() {
        // Handle initial hash
        this.handleHashChange();
        
        // Listen for hash changes
        window.addEventListener('hashchange', () => this.handleHashChange());
        
        // Handle navigation clicks
        document.addEventListener('click', (e) => {
            const navItem = e.target.closest('[data-page]');
            if (navItem) {
                e.preventDefault();
                const page = navItem.dataset.page;
                this.loadPage(page);
            }
        });
    }
    
    handleHashChange() {
        const hash = window.location.hash.substring(1) || 'home';
        this.loadPage(hash);
    }
    
    async loadPage(pageName) {
        // Update active nav items
        this.updateActiveNav(pageName);
        
        // Hide all pages
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
        
        // Show target page
        const pageEl = document.getElementById(`page-${pageName}`);
        if (pageEl) {
            pageEl.classList.add('active');
            this.currentPage = pageName;
        } else {
            // Load page content dynamically
            await this.loadDynamicPage(pageName);
        }
        
        // Update URL hash
        window.location.hash = pageName;
    }
    
    updateActiveNav(pageName) {
        // Update desktop nav
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.page === pageName);
        });
        
        // Update mobile nav
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.page === pageName);
        });
    }
    
    async loadDynamicPage(pageName) {
        try {
            const response = await fetch(`pages/${pageName}.html`);
            if (!response.ok) throw new Error('Page not found');
            
            const html = await response.text();
            
            // Create page container
            const pageContainer = document.createElement('div');
            pageContainer.id = `page-${pageName}`;
            pageContainer.className = 'page active';
            pageContainer.innerHTML = `
                <div class="page-content">
                    ${html}
                </div>
            `;
            
            // Add to main content
            const mainContent = document.getElementById('main-content');
            mainContent.appendChild(pageContainer);
            
            // Initialize page-specific scripts
            this.initializePage(pageName, pageContainer);
        } catch (error) {
            console.error('Error loading page:', error);
            
            // Show error page
            const errorPage = document.createElement('div');
            errorPage.id = `page-${pageName}`;
            errorPage.className = 'page active';
            errorPage.innerHTML = `
                <div class="page-content">
                    <div class="error-state">
                        <h2>Page Not Found</h2>
                        <p>The requested page could not be loaded.</p>
                        <button onclick="router.loadPage('home')" class="btn-primary">
                            Return Home
                        </button>
                    </div>
                </div>
            `;
            
            const mainContent = document.getElementById('main-content');
            mainContent.appendChild(errorPage);
        }
    }
    
    initializePage(pageName, container) {
        switch (pageName) {
            case 'lessons':
                this.initLessonsPage(container);
                break;
            case 'practice':
                this.initPracticePage(container);
                break;
            case 'stats':
                this.initStatsPage(container);
                break;
            case 'profile':
                this.initProfilePage(container);
                break;
            case 'settings':
                this.initSettingsPage(container);
                break;
        }
    }
    
    initLessonsPage(container) {
        // Lessons page initialization
        container.innerHTML = `
            <div class="lessons-header">
                <h1>📚 Lessons Library</h1>
                <p>Master typing step by step with structured lessons</p>
            </div>
            
            <div class="lessons-categories">
                <div class="category-card" data-category="basic">
                    <span class="category-icon">🔤</span>
                    <h3>Basic Alphabet</h3>
                    <p>Home row, upper row, lower row</p>
                    <div class="lesson-count">15 lessons</div>
                </div>
                
                <div class="category-card" data-category="numbers">
                    <span class="category-icon">🔢</span>
                    <h3>Numbers Practice</h3>
                    <p>0-9 and mixed numbers</p>
                    <div class="lesson-count">10 lessons</div>
                </div>
                
                <div class="category-card" data-category="special">
                    <span class="category-icon">#️⃣</span>
                    <h3>Special Characters</h3>
                    <p>! @ # $ % ^ & * ( )</p>
                    <div class="lesson-count">8 lessons</div>
                </div>
                
                <div class="category-card" data-category="small">
                    <span class="category-icon">📝</span>
                    <h3>Small Text</h3>
                    <p>1-2 paragraphs</p>
                    <div class="lesson-count">25 lessons</div>
                </div>
                
                <div class="category-card" data-category="medium">
                    <span class="category-icon">📄</span>
                    <h3>Medium Text</h3>
                    <p>3-5 paragraphs</p>
                    <div class="lesson-count">20 lessons</div>
                </div>
                
                <div class="category-card" data-category="large">
                    <span class="category-icon">📚</span>
                    <h3>Large Text</h3>
                    <p>10-15 minute passages</p>
                    <div class="lesson-count">15 lessons</div>
                </div>
                
                <div class="category-card" data-category="ssc">
                    <span class="category-icon">🎯</span>
                    <h3>SSC Special</h3>
                    <p>Real exam patterns</p>
                    <div class="lesson-count">30 lessons</div>
                </div>
            </div>
            
            <div id="lessons-list" class="lessons-list hidden">
                <button class="btn-outline mb-3" id="back-to-categories">
                    ← Back to Categories
                </button>
                <div id="lessons-container"></div>
            </div>
        `;
        
        // Add click handlers
        container.querySelectorAll('.category-card').forEach(card => {
            card.addEventListener('click', () => {
                const category = card.dataset.category;
                this.loadLessons(category);
            });
        });
        
        container.querySelector('#back-to-categories')?.addEventListener('click', () => {
            container.querySelector('.lessons-categories').classList.remove('hidden');
            container.querySelector('#lessons-list').classList.add('hidden');
        });
    }
    
    async loadLessons(category) {
        const container = document.getElementById('page-lessons');
        const categoriesEl = container.querySelector('.lessons-categories');
        const listEl = container.querySelector('#lessons-list');
        const lessonsContainer = container.querySelector('#lessons-container');
        
        // Show loading
        lessonsContainer.innerHTML = '<div class="loading">Loading lessons...</div>';
        
        // Hide categories, show list
        categoriesEl.classList.add('hidden');
        listEl.classList.remove('hidden');
        
        // Load lessons from JSON
        try {
            const response = await fetch(`data/lessons-${category}.json`);
            const lessons = await response.json();
            
            lessonsContainer.innerHTML = lessons.map((lesson, index) => `
                <div class="lesson-card" data-lesson-id="${lesson.id}">
                    <div class="lesson-header">
                        <span class="lesson-icon">${this.getLessonIcon(category)}</span>
                        <div>
                            <h3>Lesson ${index + 1}: ${lesson.title}</h3>
                            <p>${lesson.description}</p>
                        </div>
                    </div>
                    <div class="lesson-stats">
                        <span>📝 ${lesson.wordCount || 'N/A'} words</span>
                        <span>⏱️ ${lesson.duration || 'N/A'} min</span>
                        <span>🎯 Target: ${lesson.targetWPM || '40'} WPM</span>
                    </div>
                    <button class="btn-primary start-lesson" 
                            onclick="typingEngine.startLesson('${lesson.id}')">
                        Start Lesson
                    </button>
                </div>
            `).join('');
        } catch (error) {
            lessonsContainer.innerHTML = `
                <div class="error-state">
                    <p>Error loading lessons. Using sample lessons instead.</p>
                    ${this.getSampleLessons(category)}
                </div>
            `;
        }
    }
    
    getLessonIcon(category) {
        const icons = {
            'basic': '🔤',
            'numbers': '🔢',
            'special': '#️⃣',
            'small': '📝',
            'medium': '📄',
            'large': '📚',
            'ssc': '🎯'
        };
        return icons[category] || '📚';
    }
    
    getSampleLessons(category) {
        const sampleLessons = [
            { id: '1', title: 'Basic Lesson 1', description: 'Practice home row keys', targetWPM: 30 },
            { id: '2', title: 'Basic Lesson 2', description: 'Practice upper row keys', targetWPM: 35 },
            { id: '3', title: 'Basic Lesson 3', description: 'Practice lower row keys', targetWPM: 40 }
        ];
        
        return sampleLessons.map(lesson => `
            <div class="lesson-card">
                <div class="lesson-header">
                    <span class="lesson-icon">🔤</span>
                    <div>
                        <h3>${lesson.title}</h3>
                        <p>${lesson.description}</p>
                    </div>
                </div>
                <div class="lesson-stats">
                    <span>🎯 Target: ${lesson.targetWPM} WPM</span>
                </div>
                <button class="btn-primary start-lesson">
                    Start Lesson
                </button>
            </div>
        `).join('');
    }
    
    initPracticePage(container) {
        container.innerHTML = `
            <div class="practice-container">
                <div class="practice-header">
                    <h1>⌨️ Practice Session</h1>
                    <p>Real-time typing practice with instant feedback</p>
                </div>
                
                <div class="practice-controls">
                    <div class="lesson-selector">
                        <select id="lesson-select">
                            <option value="">Select a lesson...</option>
                            <option value="quick">Quick Practice (1 min)</option>
                            <option value="ssc">SSC Exam Simulation</option>
                            <option value="custom">Custom Text</option>
                        </select>
                        <button id="start-practice" class="btn-primary">Start Practice</button>
                    </div>
                    
                    <div class="custom-text-input hidden" id="custom-text-area">
                        <textarea placeholder="Paste or type your custom text here..." 
                                  rows="4"></textarea>
                        <button id="use-custom-text" class="btn-secondary">Use This Text</button>
                    </div>
                </div>
                
                <div class="typing-area hidden" id="typing-area">
                    <div class="stats-bar">
                        <div class="stat">
                            <span class="stat-label">Time:</span>
                            <span class="stat-value" id="timer">00:00</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">WPM:</span>
                            <span class="stat-value" id="wpm">0</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">CPM:</span>
                            <span class="stat-value" id="cpm">0</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Accuracy:</span>
                            <span class="stat-value" id="accuracy">100%</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Errors:</span>
                            <span class="stat-value" id="errors">0</span>
                        </div>
                    </div>
                    
                    <div class="text-display" id="text-display">
                        <!-- Text will be displayed here with character highlighting -->
                    </div>
                    
                    <div class="input-area">
                        <textarea id="typing-input" 
                                  placeholder="Start typing here... (Copy-paste disabled)"
                                  rows="4"
                                  disabled></textarea>
                    </div>
                    
                    <div class="typing-controls">
                        <button id="pause-btn" class="btn-outline">
                            <span>⏸️</span> Pause
                        </button>
                        <button id="restart-btn" class="btn-outline">
                            <span>🔄</span> Restart
                        </button>
                        <button id="finish-btn" class="btn-primary">
                            <span>🏁</span> Finish
                        </button>
                    </div>
                </div>
                
                <div class="results hidden" id="results">
                    <h2>Session Results</h2>
                    <div class="result-stats">
                        <div class="result-stat">
                            <h3 id="final-wpm">0</h3>
                            <p>Words Per Minute</p>
                        </div>
                        <div class="result-stat">
                            <h3 id="final-accuracy">100%</h3>
                            <p>Accuracy</p>
                        </div>
                        <div class="result-stat">
                            <h3 id="final-time">0:00</h3>
                            <p>Time</p>
                        </div>
                        <div class="result-stat">
                            <h3 id="final-errors">0</h3>
                            <p>Errors</p>
                        </div>
                    </div>
                    
                    <div class="result-feedback" id="feedback">
                        <!-- Dynamic feedback will appear here -->
                    </div>
                    
                    <div class="result-actions">
                        <button id="save-result" class="btn-primary">
                            <span>💾</span> Save Result
                        </button>
                        <button id="practice-again" class="btn-secondary">
                            <span>🔄</span> Practice Again
                        </button>
                        <button id="view-stats" class="btn-outline">
                            <span>📊</span> View Stats
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Initialize typing engine
        typingEngine.init();
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new TypeCrackPro();
    window.router = app.router;
    window.typingEngine = new TypingEngine();
});