// js/typing-engine.js
class TypingEngine {
    constructor() {
        this.isActive = false;
        this.isPaused = false;
        this.startTime = null;
        this.pauseTime = null;
        this.totalPauseTime = 0;
        this.currentText = '';
        this.userInput = '';
        this.errors = 0;
        this.totalKeystrokes = 0;
        this.correctKeystrokes = 0;
        this.currentPosition = 0;
        this.intervalId = null;
        this.currentSession = null;
        
        this.init();
    }
    
    init() {
        // Disable copy-paste on typing input
        document.addEventListener('copy', (e) => {
            if (e.target.id === 'typing-input') {
                e.preventDefault();
            }
        });
        
        document.addEventListener('paste', (e) => {
            if (e.target.id === 'typing-input') {
                e.preventDefault();
                app.showToast('Copy-paste is disabled during practice', 'warning');
            }
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (!this.isActive) return;
            
            // Pause/Resume with Ctrl+Space
            if (e.ctrlKey && e.code === 'Space') {
                e.preventDefault();
                this.togglePause();
            }
            
            // Restart with Ctrl+R
            if (e.ctrlKey && e.code === 'KeyR') {
                e.preventDefault();
                this.restart();
            }
        });
    }
    
    async startLesson(lessonId) {
        // Load lesson data
        const lesson = await this.loadLesson(lessonId);
        
        if (!lesson) {
            app.showToast('Lesson not found', 'error');
            return;
        }
        
        // Navigate to practice page
        router.loadPage('practice');
        
        // Give time for page load
        setTimeout(() => {
            this.startPractice(lesson.text, lesson.title);
        }, 100);
    }
    
    async loadLesson(lessonId) {
        // Try to load from JSON files
        const categories = ['basic', 'numbers', 'special', 'small', 'medium', 'large', 'ssc'];
        
        for (const category of categories) {
            try {
                const response = await fetch(`data/lessons-${category}.json`);
                const lessons = await response.json();
                const lesson = lessons.find(l => l.id === lessonId);
                if (lesson) return lesson;
            } catch (error) {
                continue;
            }
        }
        
        // Return sample lesson if not found
        return {
            id: lessonId,
            title: 'Sample Lesson',
            text: this.getSampleText(),
            category: 'basic'
        };
    }
    
    getSampleText() {
        const samples = [
            "The quick brown fox jumps over the lazy dog. This sentence contains all letters of the English alphabet.",
            "Typing speed and accuracy are essential skills for government job aspirants. Practice regularly to improve.",
            "Success in SSC typing tests requires consistent practice, proper finger placement, and focus on accuracy.",
            "Start with basic exercises, then gradually move to complex passages. Track your progress over time.",
            "Government exams test both speed and precision. Aim for 40+ WPM with 95%+ accuracy for success."
        ];
        
        return samples[Math.floor(Math.random() * samples.length)];
    }
    
    startPractice(text, title = 'Practice Session') {
        this.reset();
        
        this.currentText = text;
        this.currentSession = {
            title: title,
            startTime: new Date().toISOString(),
            profileId: app.currentProfile?.id || 'guest'
        };
        
        // Update UI
        const practiceArea = document.getElementById('typing-area');
        const resultsArea = document.getElementById('results');
        const textDisplay = document.getElementById('text-display');
        const typingInput = document.getElementById('typing-input');
        
        if (!practiceArea || !textDisplay || !typingInput) return;
        
        practiceArea.classList.remove('hidden');
        if (resultsArea) resultsArea.classList.add('hidden');
        
        // Display text with character spans
        textDisplay.innerHTML = text.split('').map((char, index) => {
            const isSpace = char === ' ';
            return `<span class="char ${isSpace ? 'space' : ''}" data-index="${index}">${isSpace ? '&nbsp;' : char}</span>`;
        }).join('');
        
        // Enable input
        typingInput.disabled = false;
        typingInput.value = '';
        typingInput.focus();
        
        // Add event listeners
        typingInput.addEventListener('input', (e) => this.handleInput(e));
        typingInput.addEventListener('keydown', (e) => this.handleKeyDown(e));
        
        // Setup control buttons
        const pauseBtn = document.getElementById('pause-btn');
        const restartBtn = document.getElementById('restart-btn');
        const finishBtn = document.getElementById('finish-btn');
        
        if (pauseBtn) pauseBtn.onclick = () => this.togglePause();
        if (restartBtn) restartBtn.onclick = () => this.restart();
        if (finishBtn) finishBtn.onclick = () => this.finish();
        
        // Start timer
        this.startTimer();
        this.isActive = true;
        
        app.showToast('Practice started! Focus on accuracy.', 'success');
    }
    
    handleInput(e) {
        if (this.isPaused || !this.isActive) return;
        
        const input = e.target.value;
        const lastChar = input[input.length - 1];
        const expectedChar = this.currentText[this.currentPosition];
        
        // Update current position
        this.currentPosition = input.length - 1;
        
        // Check if backspace was pressed
        if (input.length < this.userInput.length) {
            this.handleBackspace();
            this.userInput = input;
            return;
        }
        
        // Count keystroke
        this.totalKeystrokes++;
        
        // Check correctness
        const isCorrect = lastChar === expectedChar;
        
        if (isCorrect) {
            this.correctKeystrokes++;
            this.updateCharacterDisplay(this.currentPosition, 'correct');
        } else {
            this.errors++;
            this.updateCharacterDisplay(this.currentPosition, 'error');
        }
        
        // Update cursor position
        this.updateCursor();
        
        // Save current input
        this.userInput = input;
        
        // Check if completed
        if (input.length === this.currentText.length) {
            this.finish();
        }
        
        // Update stats in real-time
        this.updateStats();
    }
    
    handleKeyDown(e) {
        // Prevent default for Tab key to keep focus in input
        if (e.key === 'Tab') {
            e.preventDefault();
        }
    }
    
    handleBackspace() {
        // Reset the character at the deleted position
        const position = this.userInput.length - 1;
        if (position >= 0) {
            this.updateCharacterDisplay(position, 'pending');
        }
    }
    
    updateCharacterDisplay(position, state) {
        const charElement = document.querySelector(`.char[data-index="${position}"]`);
        if (!charElement) return;
        
        // Remove existing state classes
        charElement.classList.remove('correct', 'error', 'current');
        
        // Add new state class
        if (state !== 'pending') {
            charElement.classList.add(state);
        }
        
        // If this is the current position, add current class
        if (position === this.currentPosition && this.isActive && !this.isPaused) {
            charElement.classList.add('current');
        }
    }
    
    updateCursor() {
        // Remove current class from all characters
        document.querySelectorAll('.char.current').forEach(char => {
            char.classList.remove('current');
        });
        
        // Add current class to next character
        const nextChar = document.querySelector(`.char[data-index="${this.currentPosition + 1}"]`);
        if (nextChar) {
            nextChar.classList.add('current');
        }
    }
    
    updateStats() {
        if (!this.startTime) return;
        
        const elapsedTime = (Date.now() - this.startTime - this.totalPauseTime) / 1000; // in seconds
        const minutes = elapsedTime / 60;
        
        // Calculate WPM (words = characters / 5)
        const wordsTyped = this.correctKeystrokes / 5;
        const wpm = minutes > 0 ? Math.round(wordsTyped / minutes) : 0;
        
        // Calculate accuracy
        const accuracy = this.totalKeystrokes > 0 
            ? Math.round((this.correctKeystrokes / this.totalKeystrokes) * 100)
            : 100;
        
        // Calculate CPM
        const cpm = minutes > 0 ? Math.round(this.correctKeystrokes / minutes) : 0;
        
        // Update UI
        const timerEl = document.getElementById('timer');
        const wpmEl = document.getElementById('wpm');
        const cpmEl = document.getElementById('cpm');
        const accuracyEl = document.getElementById('accuracy');
        const errorsEl = document.getElementById('errors');
        
        if (timerEl) {
            const minutesDisplay = Math.floor(elapsedTime / 60);
            const secondsDisplay = Math.floor(elapsedTime % 60);
            timerEl.textContent = `${minutesDisplay.toString().padStart(2, '0')}:${secondsDisplay.toString().padStart(2, '0')}`;
        }
        
        if (wpmEl) wpmEl.textContent = wpm;
        if (cpmEl) cpmEl.textContent = cpm;
        if (accuracyEl) accuracyEl.textContent = `${accuracy}%`;
        if (errorsEl) errorsEl.textContent = this.errors;
    }
    
    startTimer() {
        this.startTime = Date.now();
        this.totalPauseTime = 0;
        
        this.intervalId = setInterval(() => {
            if (!this.isPaused) {
                this.updateStats();
            }
        }, 100);
    }
    
    togglePause() {
        this.isPaused = !this.isPaused;
        const typingInput = document.getElementById('typing-input');
        const pauseBtn = document.getElementById('pause-btn');
        
        if (this.isPaused) {
            this.pauseTime = Date.now();
            if (typingInput) typingInput.disabled = true;
            if (pauseBtn) {
                pauseBtn.innerHTML = '<span>▶️</span> Resume';
            }
            app.showToast('Practice paused', 'info');
        } else {
            this.totalPauseTime += Date.now() - this.pauseTime;
            if (typingInput) typingInput.disabled = false;
            if (pauseBtn) {
                pauseBtn.innerHTML = '<span>⏸️</span> Pause';
            }
            typingInput.focus();
            app.showToast('Practice resumed', 'success');
        }
    }
    
    restart() {
        if (!confirm('Are you sure you want to restart? Current progress will be lost.')) {
            return;
        }
        
        this.reset();
        this.startPractice(this.currentText, this.currentSession?.title);
    }
    
    async finish() {
        if (!this.isActive) return;
        
        this.isActive = false;
        clearInterval(this.intervalId);
        
        // Calculate final stats
        const elapsedTime = (Date.now() - this.startTime - this.totalPauseTime) / 1000;
        const minutes = elapsedTime / 60;
        const wordsTyped = this.correctKeystrokes / 5;
        const wpm = minutes > 0 ? Math.round(wordsTyped / minutes) : 0;
        const accuracy = this.totalKeystrokes > 0 
            ? Math.round((this.correctKeystrokes / this.totalKeystrokes) * 100)
            : 100;
        
        // Save session
        const sessionData = {
            profileId: app.currentProfile?.id || 'guest',
            title: this.currentSession?.title || 'Practice Session',
            wpm: wpm,
            accuracy: accuracy,
            errors: this.errors,
            duration: elapsedTime,
            wordCount: Math.floor(wordsTyped),
            keystrokes: this.totalKeystrokes,
            textLength: this.currentText.length
        };
        
        await storage.saveSession(sessionData);
        
        // Update UI with results
        this.showResults(wpm, accuracy, elapsedTime, this.errors);
        
        // Update quick stats on home page
        app.loadQuickStats();
        
        app.showToast('Practice completed! Results saved.', 'success');
    }
    
    showResults(wpm, accuracy, time, errors) {
        const practiceArea = document.getElementById('typing-area');
        const resultsArea = document.getElementById('results');
        const finalWpmEl = document.getElementById('final-wpm');
        const finalAccuracyEl = document.getElementById('final-accuracy');
        const finalTimeEl = document.getElementById('final-time');
        const finalErrorsEl = document.getElementById('final-errors');
        const feedbackEl = document.getElementById('feedback');
        
        if (!practiceArea || !resultsArea) return;
        
        practiceArea.classList.add('hidden');
        resultsArea.classList.remove('hidden');
        
        // Update result values
        if (finalWpmEl) finalWpmEl.textContent = wpm;
        if (finalAccuracyEl) finalAccuracyEl.textContent = `${accuracy}%`;
        if (finalTimeEl) {
            const minutes = Math.floor(time / 60);
            const seconds = Math.floor(time % 60);
            finalTimeEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }
        if (finalErrorsEl) finalErrorsEl.textContent = errors;
        
        // Generate feedback
        let feedback = '';
        if (wpm >= 50) {
            feedback = '<div class="feedback-excellent">🚀 Excellent Speed! You\'re SSC ready!</div>';
        } else if (wpm >= 40) {
            feedback = '<div class="feedback-good">👍 Good speed! Keep practicing to reach 50+ WPM.</div>';
        } else if (wpm >= 30) {
            feedback = '<div class="feedback-average">📈 Average speed. Focus on accuracy and gradually increase speed.</div>';
        } else {
            feedback = '<div class="feedback-beginner">🎯 Beginner level. Practice daily for improvement.</div>';
        }
        
        if (accuracy >= 95) {
            feedback += '<div class="feedback-accuracy">🎯 Accuracy Master! Excellent precision.</div>';
        } else if (accuracy >= 90) {
            feedback += '<div class="feedback-accuracy">✨ Good accuracy. Aim for 95%+.</div>';
        } else {
            feedback += '<div class="feedback-accuracy">💡 Focus on accuracy. Slow down if needed.</div>';
        }
        
        if (feedbackEl) feedbackEl.innerHTML = feedback;
        
        // Add event listeners to result buttons
        const saveResultBtn = document.getElementById('save-result');
        const practiceAgainBtn = document.getElementById('practice-again');
        const viewStatsBtn = document.getElementById('view-stats');
        
        if (saveResultBtn) saveResultBtn.onclick = () => {
            app.showToast('Result already saved to your profile', 'info');
        };
        
        if (practiceAgainBtn) practiceAgainBtn.onclick = () => {
            this.startPractice(this.currentText, this.currentSession?.title);
        };
        
        if (viewStatsBtn) viewStatsBtn.onclick = () => {
            router.loadPage('stats');
        };
    }
    
    reset() {
        this.isActive = false;
        this.isPaused = false;
        this.startTime = null;
        this.pauseTime = null;
        this.totalPauseTime = 0;
        this.currentText = '';
        this.userInput = '';
        this.errors = 0;
        this.totalKeystrokes = 0;
        this.correctKeystrokes = 0;
        this.currentPosition = 0;
        
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    }
}