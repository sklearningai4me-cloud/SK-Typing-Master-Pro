// utils/constants.js
const Constants = {
    // Typing targets
    TARGET_WPM: {
        BEGINNER: 20,
        INTERMEDIATE: 35,
        ADVANCED: 50,
        SSC_REQUIRED: 35,
        STENO_REQUIRED: 60
    },
    
    TARGET_ACCURACY: {
        MINIMUM: 85,
        GOOD: 90,
        EXCELLENT: 95,
        SSC_REQUIRED: 95
    },
    
    // Practice durations (in minutes)
    PRACTICE_DURATIONS: {
        QUICK: 1,
        SHORT: 5,
        MEDIUM: 10,
        LONG: 15,
        SSC_TEST: 10
    },
    
    // Lesson categories
    LESSON_CATEGORIES: {
        BASIC: 'basic',
        NUMBERS: 'numbers',
        SPECIAL: 'special',
        SMALL: 'small',
        MEDIUM: 'medium',
        LARGE: 'large',
        SSC: 'ssc'
    },
    
    // Achievement levels
    ACHIEVEMENT_LEVELS: {
        BEGINNER: 'beginner',
        INTERMEDIATE: 'intermediate',
        ADVANCED: 'advanced',
        EXPERT: 'expert',
        MASTER: 'master'
    },
    
    // Certificate types
    CERTIFICATE_TYPES: {
        WPM: 'wpm',
        ACCURACY: 'accuracy',
        CONSISTENCY: 'consistency',
        SSC: 'ssc',
        DAILY: 'daily'
    },
    
    // Themes
    THEMES: {
        LIGHT: 'light',
        DARK: 'dark',
        SEPIA: 'sepia',
        NIGHT_BLUE: 'night-blue',
        GREEN_MATRIX: 'green-matrix',
        PAPER_WHITE: 'paper-white',
        SSC_EXAM: 'ssc-exam'
    },
    
    // Sound types
    SOUND_TYPES: {
        KEY_PRESS: 'key_press',
        ERROR: 'error',
        SUCCESS: 'success',
        COMPLETE: 'complete'
    },
    
    // LocalStorage keys
    STORAGE_KEYS: {
        SETTINGS: 'typecrack_settings',
        PROFILES: 'typecrack_profiles',
        CURRENT_PROFILE: 'typecrack_current_profile',
        THEME: 'theme',
        ACCESSIBILITY: 'accessibility'
    },
    
    // IndexedDB configuration
    DB_CONFIG: {
        NAME: 'TypeCrackDB',
        VERSION: 1,
        STORES: {
            PROFILES: 'profiles',
            SESSIONS: 'sessions',
            STATS: 'stats',
            SETTINGS: 'settings'
        }
    },
    
    // PWA configuration
    PWA_CONFIG: {
        CACHE_NAME: 'typecrack-pro-v1',
        OFFLINE_PAGE: '/offline.html'
    },
    
    // Exam patterns
    EXAM_PATTERNS: {
        SSC: {
            MIN_WPM: 35,
            MIN_ACCURACY: 95,
            DURATION: 10, // minutes
            LANGUAGE: 'english',
            ALLOWED_ERRORS: 5 // percentage
        },
        CHSL: {
            MIN_WPM: 35,
            MIN_ACCURACY: 95,
            DURATION: 10,
            LANGUAGE: 'english'
        },
        STENO: {
            MIN_WPM: 60,
            MIN_ACCURACY: 98,
            DURATION: 10,
            LANGUAGE: 'english'
        }
    },
    
    // Default settings
    DEFAULT_SETTINGS: {
        theme: 'light',
        sound: true,
        fontSize: 'medium',
        showKeyboard: true,
        errorHighlight: true,
        autoSave: true,
        practiceDuration: 5,
        wpmCalculation: 'standard'
    },
    
    // Keyboard layouts
    KEYBOARD_LAYOUTS: {
        QWERTY: 'qwerty',
        DVORAK: 'dvorak',
        COLEMAK: 'colemak'
    },
    
    // Languages
    LANGUAGES: {
        EN: 'English',
        HI: 'Hindi',
        TA: 'Tamil',
        TE: 'Telugu',
        KN: 'Kannada',
        ML: 'Malayalam'
    },
    
    // Version
    VERSION: '1.0.0',
    BUILD_DATE: '2024-01-20',
    
    // Developer
    DEVELOPER: {
        NAME: 'TypeCrack Team',
        WEBSITE: 'https://typecrack.example.com',
        CONTACT: 'contact@typecrack.example.com'
    }
};

// Export if using modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Constants, Helpers };
}