// utils/helpers.js
class Helpers {
    static formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    
    static formatDate(date) {
        const d = new Date(date);
        return d.toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }
    
    static formatDateTime(date) {
        const d = new Date(date);
        return d.toLocaleString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    static calculateWPM(characters, minutes) {
        if (minutes === 0) return 0;
        const words = characters / 5;
        return Math.round(words / minutes);
    }
    
    static calculateAccuracy(totalKeystrokes, errors) {
        if (totalKeystrokes === 0) return 100;
        return Math.round(((totalKeystrokes - errors) / totalKeystrokes) * 100);
    }
    
    static getRandomTip() {
        const tips = [
            "Keep your fingers on the home row keys (ASDF JKL;) for better typing efficiency.",
            "Use the correct finger for each key to build muscle memory faster.",
            "Practice daily for 15-30 minutes rather than long sessions occasionally.",
            "Focus on accuracy first, speed will come naturally with practice.",
            "Don't look at the keyboard while typing to develop touch typing skills.",
            "Take breaks every 20-30 minutes to avoid strain and fatigue.",
            "Use all fingers, not just index fingers, for faster typing.",
            "Maintain proper posture: sit straight, feet flat, screen at eye level.",
            "Practice with different types of content: numbers, symbols, and text.",
            "Track your progress regularly to stay motivated and identify areas for improvement.",
            "For SSC exams, aim for 35-40 WPM with 95%+ accuracy.",
            "Use online typing tests to simulate exam conditions.",
            "Read ahead while typing to improve speed and reduce errors.",
            "Keep your wrists straight and slightly elevated while typing.",
            "Use keyboard shortcuts to improve overall computer efficiency.",
            "Practice typing without backspacing to improve accuracy.",
            "Try typing games to make practice more enjoyable.",
            "Use a mechanical keyboard for better tactile feedback if possible.",
            "Set daily goals and celebrate small achievements.",
            "Join typing communities for motivation and tips."
        ];
        
        return tips[Math.floor(Math.random() * tips.length)];
    }
    
    static getCompliment(wpm, accuracy) {
        if (wpm >= 50 && accuracy >= 95) {
            return { text: "🚀 Excellent Speed! You're SSC ready!", type: "excellent" };
        } else if (wpm >= 40 && accuracy >= 90) {
            return { text: "👍 Great progress! Keep practicing!", type: "good" };
        } else if (wpm >= 30 && accuracy >= 85) {
            return { text: "📈 Good start! Focus on accuracy.", type: "average" };
        } else {
            return { text: "💪 Keep practicing! You'll improve.", type: "beginner" };
        }
    }
    
    static generateSessionId() {
        return Date.now().toString() + Math.random().toString(36).substr(2, 9);
    }
    
    static sanitizeText(text) {
        return text
            .replace(/[^\x00-\x7F]/g, '') // Remove non-ASCII characters
            .replace(/\s+/g, ' ')         // Replace multiple spaces with single space
            .trim();
    }
    
    static getWordCount(text) {
        return text.split(/\s+/).filter(word => word.length > 0).length;
    }
    
    static getCharacterCount(text) {
        return text.replace(/\s/g, '').length;
    }
    
    static estimateReadingTime(text) {
        const words = this.getWordCount(text);
        const minutes = words / 200; // Average reading speed
        return Math.ceil(minutes);
    }
    
    static formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    static copyToClipboard(text) {
        return navigator.clipboard.writeText(text);
    }
    
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    static throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    static validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    static getDeviceType() {
        const ua = navigator.userAgent;
        if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
            return 'mobile';
        }
        return 'desktop';
    }
    
    static isPWAInstalled() {
        return window.matchMedia('(display-mode: standalone)').matches || 
               window.navigator.standalone === true;
    }
    
    static getBrowserInfo() {
        const ua = navigator.userAgent;
        let browser = "Unknown";
        
        if (ua.includes("Chrome") && !ua.includes("Edg")) browser = "Chrome";
        else if (ua.includes("Firefox")) browser = "Firefox";
        else if (ua.includes("Safari") && !ua.includes("Chrome")) browser = "Safari";
        else if (ua.includes("Edg")) browser = "Edge";
        
        return browser;
    }
    
    static async checkStorageQuota() {
        if ('storage' in navigator && 'estimate' in navigator.storage) {
            const estimate = await navigator.storage.estimate();
            return {
                used: estimate.usage,
                quota: estimate.quota,
                percentage: (estimate.usage / estimate.quota) * 100
            };
        }
        return null;
    }
    
    static generatePassword(length = 12) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
        let password = '';
        for (let i = 0; i < length; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    }
}